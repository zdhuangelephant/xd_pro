/**
 * Created by Administrator on 2015/6/3.
 */
 $(document).ready(function(){
     TweenMax.to(".exam",1,{top:"40%",ease:Power1.Elastic}); TweenMax.to(".exam",1,{top:"70px",globalTimeScale:3});
     TweenMax.to(".chapter",1,{top:"90%",ease:Power1.Elastic}); TweenMax.to(".chapter",1,{top:"106px",delay:0.09});
     TweenMax.to(".chapter1",1,{top:"90%",ease:Power1.Elastic}); TweenMax.to(".chapter",1,{top:"30",delay:0.09});
     TweenMax.to(".detail",1,{top:"100%",ease:Power1.Elastic}); TweenMax.to(".detail",1,{top:"140px",delay:0.2});
     TweenMax.to(".detail2",1,{top:"110%",ease:Power1.Elastic}); TweenMax.to(".detail2",1,{top:"90px",delay:1});
     TweenMax.to(".detail2",1,{top:"110%",ease:Power1.Elastic}); TweenMax.to(".detail2",1,{top:"90px",delay:1});
     TweenMax.to(".detail3",1,{top:"110%",ease:Power1.Elastic}); TweenMax.to(".detail3",1,{top:"80px",delay:1});
     //TweenMax.to("#exam",1,{top:240,ease:Back.easeOut});
     //TweenMax.to(".star1",1,{autoAlpha:0,ease:Back.easeOut,repeat:-1,repeatDelay:1})//透明度
     //setTimeout(function () {
     //    $(".p42014").show();
     //    $(".p4text").show();
     //    wordEastIn(data[0], data[1], data[2]);
     //}, 4000);
 });
