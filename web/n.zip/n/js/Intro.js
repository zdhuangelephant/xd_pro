/**
 * 会议介绍
 */

var Intro = function(id) {
	this.id = id;
	this.swipeRight = function(evt) {
		director.replaceScene(new Cover('page1'), director.TransitionMoveInT);
	};
	this.swipeLeft = function(evt) {
		director.replaceScene(new Guest('page3'), director.TransitionMoveInB);
	};
};
Intro.prototype.onReady = function() {
    //var w = 100%;
    //$("#stage").width(200);
    //TweenMax.to(".exam",1,{top:"40%",ease:Power1.Elastic}); TweenMax.to(".exam",1,{top:"70px",globalTimeScale:3});
    //TweenMax.to(".chapter1",1,{top:"100%",ease:Power1.Elastic}); TweenMax.to(".chapter",1,{top:"30",delay:1});
    //TweenMax.to(".detail2",1,{top:"100%",ease:Power1.Elastic}); TweenMax.to(".detail2",1,{top:"90px",delay:1.5});
};
Intro.prototype.onEnter = function() {
	director.bindSwipeRight(this.swipeRight);
	director.bindSwipeLeft(this.swipeLeft);
};
Intro.prototype.onExit = function() {
	// 解绑事件
	director.unbindSwipeRight(this.swipeRight);
	director.unbindSwipeLeft(this.swipeLeft);
};
