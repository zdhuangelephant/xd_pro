/**
 * 会议安排
 */

var Agenda = function(id) {
	this.id = id;
	this.swipeDown = function(evt) {
		director.replaceScene(new Guest('page3'), director.TransitionMoveInT);
	};
	//this.swipeUp = function(evt) {
	//	director.replaceScene(new Sponsor('sponsor'), director.TransitionMoveInB);
	//};
	this.lock = false;
	//this.hammer = null;

	var self = this;
	this.swipeLeft = function(evt) {
		if (self.lock) {
			return;
		}
		self.lock = true;
		var tx = $('#agenda_schedule').css('left');
		tx = (tx == 'auto') ? 0 : parseInt(tx);
		if (tx <= -800) {
			self.lock = false;
			return;
		}
		tx -= 160;
		TweenMax.to('#agenda_schedule', 0.3, {css:{left:tx}, ease:Power3.easeOut
			, onComplete:function() {
				self.lock = false;
			}});
	};
	this.swipeRight = function(evt) {
		if (self.lock) {
			return;
		}
		self.lock = true;
		var tx = $('#agenda_schedule').css('left');
		tx = (tx == 'auto') ? 0 : parseInt(tx);
		if (tx >= 0) {
			self.lock = false;
			return;
		}
		tx += 160;
		TweenMax.to('#agenda_schedule', 0.3, {css:{left:tx}, ease:Power3.easeOut
			, onComplete:function() {
				self.lock = false;
			}});
	};
	touch.on('#agenda_schedule', "swipeleft", this.swipeLeft);
	touch.on('#agenda_schedule', "swiperight", this.swipeRight);
}

Agenda.prototype.onReady = function() {
    TweenMax.to(".exam",1,{top:"40%",ease:Power1.Elastic}); TweenMax.to(".exam",1,{top:"70px",globalTimeScale:3,delay:1});
    TweenMax.to(".chapter",1,{top:"90%",ease:Power1.Elastic}); TweenMax.to(".chapter",1,{top:"106px",delay:1.09});
    TweenMax.to(".detail",1,{top:"100%",ease:Power1.Elastic}); TweenMax.to(".detail",1,{top:"140px",delay:1.2});
	this.lock = false;
	var el = $('#agenda_schedule');
	el.css('left', 0);
	el.css('top', parseInt(window.stageHeight * 0.15));

	var w = parseInt(window.stageWidth * 0.33);
	el = $('#agenda_info');
	el.css('top', window.stageHeight);
	el.find('.agenda_date').width(w);
	el.find('.agenda_date').height(w);
	el.find('.agenda_desc').height(w);
	$('.agenda_desc').width(window.stageWidth - w);

	$('.agenda_cal').css('font-size', parseInt(w / 8));
	$('.agenda_cal .day').css('font-size', parseInt(w / 1.8));

	$('.agenda_table table').height(w);
}

Agenda.prototype.onEnter = function() {
	$('#agenda_arrow_down').bind('click', this.swipeDown);
	$('#agenda_arrow_up').bind('click', this.swipeUp);
	TweenMax.to('#agenda_arrow_down', 1, {startAt:{y:0}, y:12, ease:Power1.easeOut, repeat:-1, yoyo:true});
	TweenMax.to('#agenda_arrow_up', 1, {startAt:{y:0}, y:-12, ease:Power1.easeOut, repeat:-1, yoyo:true});

	// 绑定事件
	director.bindSwipeDown(this.swipeDown);
	director.bindSwipeUp(this.swipeUp);

	//this.hammer = Hammer(document.getElementById('agenda_schedule'));
	//this.hammer.on("swipeleft", this.swipeLeft);
	//this.hammer.on("swiperight", this.swipeRight);

	var el = $('#agenda_schedule');
	var ty = parseInt(el.css('top')) + parseInt(el.css('height')) + 60;
	TweenMax.to('#agenda_info', 1, {css:{top:ty}, ease:Power2.easeOut});
}

Agenda.prototype.onExit = function() {
	//this.hammer.off("swiperight", this.swipeRight);
	//this.hammer.off("swipeleft", this.swipeLeft);

	// 解绑事件
	director.unbindSwipeDown(this.swipeDown);
	director.unbindSwipeUp(this.swipeUp);

	TweenMax.killTweensOf('#agenda_arrow_down');
	TweenMax.killTweensOf('#agenda_arrow_up');
	$('#agenda_arrow_down').unbind('click', this.swipeDown);
	$('#agenda_arrow_up').unbind('click', this.swipeUp);

	TweenMax.killTweensOf('#agenda_schedule');
}
