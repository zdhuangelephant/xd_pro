/**
 * 嘉宾介绍
 */

var Guest = function(id) {
	this.id = id;
	this.swipeRight = function(evt) {
		director.replaceScene(new Intro('page2'), director.TransitionMoveInT);
	};
	this.swipeLeft = function(evt) {
		director.replaceScene(new Agenda('page4'), director.TransitionMoveInB);
	};

	this.leftList = ['guest_1', 'guest_3', 'guest_5'];
	this.leftNameList = ['guest_name_1', 'guest_name_3', 'guest_name_5'];

	this.rightList = ['guest_2', 'guest_4', 'guest_6'];
	this.rightNameList = ['guest_name_2', 'guest_name_4', 'guest_name_6'];

	this.imgWidth = 0;
	this.gap = 0;
}

Guest.prototype.onReady = function() {
    //TweenMax.to(".chapter1",1,{top:"100%",ease:Power1.Elastic}); TweenMax.to(".chapter",1,{top:"30",delay:1});
    //TweenMax.to(".detail3",1,{top:"100%",ease:Power1.Elastic}); TweenMax.to(".detail3",1,{top:"80px",delay:1.5});
	// 计算间隔、图片大小等参数
	var w = window.stageWidth * 0.3;
	var h = w / parseInt($('#guest_1 img').width()) * parseInt($('#guest_1 img').height());
	// 垂直方向间隔
	var tg = parseInt(window.stageHeight * 0.2);
	if (tg < 30)
		tg = 30;
	var space = parseInt((window.stageHeight - (3 * h) - (tg + tg)) * 0.5);
	// 水平方向间隔
	var gap = parseInt((window.stageWidth - (w + w)) / 3);
	var barW = gap + w - 6;

	// 图片宽度
	this.imgWidth = w;
	this.gap = gap;

	var x = 0;
	var y = 80;
	var yList = [];

	// 左侧
	var list = this.leftList;
	for (var i = 0; i < list.length; ++i) {
		var el = $('#' + list[i]);
		el.css('top', y);
		el.css('left', -w);

		el.find('img').width(w);

		yList.push(y);
		y += (space + h);
	}

	list = this.leftNameList;
	for (var i = 0; i < list.length; ++i) {
		var el = $('#' + list[i]);
		el.css('top', yList[i] + h - 34);
		el.css('left', -barW);
		el.width(barW);
	}

	// 右侧
	y = 120;
	yList = [];
	list = this.rightList;

	for (var i = 0; i < list.length; ++i) {
		var el = $('#' + list[i]);
		el.css('top', y);
		el.css('left', window.stageWidth);

		el.find('img').width(w);

		yList.push(y);
		y += (space + h);
	}

	list = this.rightNameList;
	for (var i = 0; i < list.length; ++i) {
		var el = $('#' + list[i]);
		el.css('top', yList[i] + h - 34);
		el.css('left', window.stageWidth);
		el.width(barW);
	}
}

Guest.prototype.onEnter = function() {
	$('#guest_arrow_Right').bind('click', this.swipeRight);
	$('#guest_arrow_Left').bind('click', this.swipeLeft);
	TweenMax.to('#guest_arrow_Right', 1, {startAt:{y:0}, y:12, ease:Power1.easeOut, repeat:-1, yoyo:true});
	TweenMax.to('#guest_arrow_Left', 1, {startAt:{y:0}, y:-12, ease:Power1.easeOut, repeat:-1, yoyo:true});

	// 绑定事件
	director.bindSwipeRight(this.swipeRight);
	director.bindSwipeLeft(this.swipeLeft);

	// 左侧动画
	var delay = 0;
	for (var i = 0; i < this.leftList.length; ++i) {
		var sx = -this.imgWidth;
		var tx = this.gap;
		TweenMax.to('#' + this.leftList[i], 0.5, {startAt:{css:{left:sx}}, css:{left:tx}, ease:Power4.easeOut, delay:delay});
		delay += 0.2;
	}

	delay = 0.5;
	for (var i = 0; i < this.leftNameList.length; ++i) {
		TweenMax.to('#' + this.leftNameList[i], 0.5, {css:{left:0}, ease:Power4.easeOut, delay:delay});
		delay += 0.2;
	}

	// 右侧动画
	delay = 0.1;
	for (var i = 0; i < this.rightList.length; ++i) {
		var sx = window.stageWidth;
		var tx = window.stageWidth - this.gap - this.imgWidth;
		TweenMax.to('#' + this.rightList[i], 0.5, {startAt:{css:{left:sx}}, css:{left:tx}, ease:Power4.easeOut, delay:delay});
		delay += 0.2;
	}

	delay = 0.6;
	for (var i = 0; i < this.rightNameList.length; ++i) {
		var tx = window.stageWidth - this.gap - this.imgWidth + 6;
		TweenMax.to('#' + this.rightNameList[i], 0.5, {css:{left:tx}, ease:Power4.easeOut, delay:delay});
		delay += 0.2;
	}
}

Guest.prototype.onExit = function() {
	for (var i = 0; i < this.leftList.length; ++i) {
		TweenMax.killTweensOf('#' + this.leftList[i]);
	}
	for (var i = 0; i < this.leftNameList.length; ++i) {
		TweenMax.killTweensOf('#' + this.leftNameList[i]);
	}
	for (var i = 0; i < this.rightList.length; ++i) {
		TweenMax.killTweensOf('#' + this.rightList[i]);
	}
	for (var i = 0; i < this.rightNameList.length; ++i) {
		TweenMax.killTweensOf('#' + this.rightNameList[i]);
	}

	// 解绑事件
	director.unbindSwipeRight(this.swipeRight);
	director.unbindSwipeLeft(this.swipeLeft);

	TweenMax.killTweensOf('#guest_arrow_Right');
	TweenMax.killTweensOf('#guest_arrow_Left');
	$('#guest_arrow_Right').unbind('click', this.swipeRight);
	$('#guest_arrow_Left').unbind('click', this.swipeLeft);
}
