/**
 * 封面
 */
var Cover = function(id) {
	this.id = id;
	this.swipeLeft = function(evt) {
		director.replaceScene(new Intro('page2'), director.TransitionMoveInB);
	};
	var cs = $('#circle_spin');
	var csSize = parseInt(window.stageWidth * 3 / 5);
	if (csSize < 340) {
		cs.width(csSize);
		cs.height(csSize);
	}
	//cs.css('left', (window.stageWidth - parseInt(cs.width())) * 0.5);
	var title = $('#cover_title');
	title.css('top', cs.height() * 0.5 - 60);
};
Cover.prototype.onReady = function() {
	// Nothing
};
Cover.prototype.onEnter = function() {
	//$('#page1next').bind('click', this.swipeUp);
	// 绑定事件
	director.bindSwipeLeft(this.swipeLeft);
};
Cover.prototype.onExit = function() {
	// 解绑事件
	director.unbindSwipeLeft(this.swipeLeft);
};